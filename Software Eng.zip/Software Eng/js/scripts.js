function calculateArea() {
  var sideLength = parseFloat(document.getElementById('side-length').value);
  if (!isNaN(sideLength)) {
      var area = sideLength * sideLength;
      document.getElementById('result').innerText = 'Luas: ' + area + 'cm²';
  } else {
      document.getElementById('result').innerText = 'Masukkan nilai sisi yang valid.';
  }
}
